(() => {
  const params = new URLSearchParams(window.location.search);
  const moduleId = params.get("module");
  const modules = {
    "2024": {
      year: 2024,
      title: "Helyesírás gyakorlás 2024",
      subtitle: "2024. januári felvételi feladatok",
      scripts: ["modules/2024/tasks.js", "practice.js", "practice-numbers.js", "scorm.js", "app-2024.js", "rewards.js", "attempt-lock.js", "module-fixes.js"]
    }
  };
  function setScoreboard(total) {
    const progressText = document.getElementById("progressText");
    const scoreText = document.getElementById("scoreText");
    const totalText = document.getElementById("totalText");
    if (progressText) progressText.textContent = `0 / ${total}`;
    if (scoreText) scoreText.textContent = "0 / 0";
    if (totalText) totalText.textContent = String(total);
  }
  function renderLauncher() {
    const scoreboard = document.querySelector(".scoreboard");
    const progressTrack = document.querySelector(".progress-track");
    if (scoreboard) scoreboard.hidden = true;
    if (progressTrack) progressTrack.hidden = true;
    const app = document.getElementById("app");
    app.innerHTML = `<section class="module-launcher"><div class="module-launcher-head"><span class="badge">Felvételi tréner</span><h2>Helyesírás</h2><p class="lead">2024. januári helyesírási feladatok.</p></div><div class="module-grid"><a class="module-card" href="?module=2024"><span class="module-year">2024</span><span class="module-copy"><strong>Helyesírás gyakorlás 2024</strong><small>2024. januári felvételi feladatok</small></span><span class="module-arrow" aria-hidden="true">→</span></a></div></section>`;
  }
  function loadSequentially(paths) {
    return paths.reduce((promise, src) => promise.then(() => new Promise((resolve, reject) => {
      const script = document.createElement("script"); script.src = src; script.onload = resolve;
      script.onerror = () => reject(new Error(`Nem sikerült betölteni: ${src}`)); document.body.appendChild(script);
    })), Promise.resolve());
  }
  if (!moduleId) { renderLauncher(); return; }
  const selected = modules[moduleId]; if (!selected) { renderLauncher(); return; }
  document.documentElement.dataset.module = moduleId;
  document.title = `Felvételi tréner – Helyesírás ${selected.year}`;
  const h1 = document.querySelector(".topbar h1"); if (h1) h1.textContent = `Helyesírás ${selected.year}`;
  const scoreboard = document.querySelector(".scoreboard"); const progressTrack = document.querySelector(".progress-track");
  if (scoreboard) scoreboard.hidden = false; if (progressTrack) progressTrack.hidden = false; setScoreboard(12);
  loadSequentially(selected.scripts).catch(error => { console.error(error); document.getElementById("app").innerHTML = `<section class="hero"><div class="hero-inner"><h2>Betöltési hiba</h2><p class="lead">A 2024-es modul nem tölthető be.</p></div></section>`; });
})();
