(() => {
  const params = new URLSearchParams(window.location.search);
  const moduleId = params.get("module") || "2023";
  const selected = {
    year: 2023,
    scripts: ["modules/2023/tasks.js", "practice.js", "practice-numbers.js", "scorm.js", "app-2023.js", "rewards.js", "attempt-lock.js", "module-fixes.js"]
  };
  if (moduleId !== "2023") window.history.replaceState(null, "", "?module=2023");
  document.documentElement.dataset.module = "2023";
  document.title = "Felvételi tréner – Helyesírás 2023";
  const h1 = document.querySelector(".topbar h1");
  if (h1) h1.textContent = "Helyesírás 2023";
  const scoreboard = document.querySelector(".scoreboard");
  const progressTrack = document.querySelector(".progress-track");
  if (scoreboard) scoreboard.hidden = false;
  if (progressTrack) progressTrack.hidden = false;
  const totalText = document.getElementById("totalText");
  const progressText = document.getElementById("progressText");
  const scoreText = document.getElementById("scoreText");
  if (totalText) totalText.textContent = "10";
  if (progressText) progressText.textContent = "0 / 10";
  if (scoreText) scoreText.textContent = "0 / 0";
  selected.scripts.reduce((p, src) => p.then(() => new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = src;
    s.onload = resolve;
    s.onerror = () => reject(new Error(`Nem sikerült betölteni: ${src}`));
    document.body.appendChild(s);
  })), Promise.resolve()).catch(error => {
    console.error(error);
    document.getElementById("app").innerHTML = `<section class="hero"><div class="hero-inner"><h2>Betöltési hiba</h2><p class="lead">A 2023-as modul nem tölthető be.</p></div></section>`;
  });
})();
