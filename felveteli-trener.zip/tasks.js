const TASKS = [
  {
    id: 1,
    source: "2026. január • központi felvételi • 5. feladat • a)",
    first: "mond",
    second: "mondd",
    correct: "both",
    tags: ["igeragozás", "felszólító mód"],
    explanation: "Mindkettő helyes: a mond kijelentő módú alak, a mondd felszólító módú, határozott ragozású alak.",
    learn: {
      title: "Mikor írjuk azt, hogy mond, és mikor azt, hogy mondd?",
      comparison: [
        { word: "mond", subtitle: "Kijelentő mód", examples: [
          { correct: true, text: "Péter igazat mond." },
          { correct: false, text: "Péter igazat mondd." }
        ]},
        { word: "mondd", subtitle: "Felszólító mód, határozott ragozás", examples: [
          { correct: true, text: "Mondd el az igazat!" },
          { correct: false, text: "Mond el az igazat!" }
        ]}
      ],
      ruleTitle: "Miért két d?",
      rule: "A mond ige töve d-re végződik. Ehhez kapcsolódik a felszólító mód -d jele:",
      formula: "mond + d = mondd",
      counterTitle: "Nem minden felszólító alakban van két d",
      counterText: "Az írd, kérd, hagyd alakokban csak egy d van, mert az igető nem d-re végződik.",
      irregularTitle: "Rendhagyó alakok",
      irregulars: ["vidd", "idd", "edd", "tedd", "vedd"],
      image: "magyarazat01.png",
      imageAlt: "Infografika a mond és mondd alak használatáról"
    }
  },
  {
    id: 2,
    source: "2026. január • központi felvételi • 5. feladat • b)",
    first: "muszáj",
    second: "muszály",
    correct: "first",
    tags: ["j–ly"],
    explanation: "A muszáj szó végén j-t írunk.",
    learn: {
      title: "Ezt érdemes megjegyezni",
      body: "A muszáj szó helyes alakjában j szerepel. Ez hagyományos írásmód, ezért leginkább gyakorlással rögzíthető.",
      rule: "Helyes alak: muszáj."
    }
  },
  {
    id: 3,
    source: "2026. január • központi felvételi • 5. feladat • c)",
    first: "megakarta beszélni",
    second: "meg akarta beszélni",
    correct: "second",
    tags: ["igekötő", "egybe- és különírás", "közbeékelődés"],
    explanation: "Ha az igekötő és az ige közé más szó kerül, az igekötőt különírjuk: meg akarta beszélni.",
    learn: {
      title: "Mikor írjuk külön, és mikor egybe az igekötős igét?",
      comparison: [
        { word: "Különírjuk", subtitle: "Ha az igekötő és az ige közé más szó ékelődik", examples: [
          { correct: true, text: "meg akarta beszélni" },
          { correct: true, text: "meg fogja beszélni" },
          { correct: true, text: "el szeretné mondani" },
          { correct: true, text: "ki tudja nyitni" },
          { correct: true, text: "be kell vinni" },
          { correct: false, text: "megakarta beszélni" }
        ]},
        { word: "Egybeírjuk", subtitle: "Ha nincs közbeékelődés: az igekötő közvetlenül az igéhez kapcsolódik", examples: [
          { correct: true, text: "megbeszéli a dolgot" },
          { correct: true, text: "kinyitja az ajtót" },
          { correct: true, text: "beviszi a csomagot" },
          { correct: true, text: "megfogja a ceruzát" },
          { correct: false, text: "meg beszéli a dolgot" }
        ]}
      ],
      ruleTitle: "Vigyázz a fog szóval!",
      rule: "A meg fogja beszélni szerkezetben a fogja a jövő idejű összetett igealak része, ezért különírjuk. A megfogja a ceruzát mondatban a fog valódi cselekvést kifejező ige, ezért az igekötővel egybeírjuk.",
      formula: "meg fogja beszélni ↔ megfogja a ceruzát",
      counterTitle: "A közbeékelődés a döntő",
      counterText: "Ha az igekötő és az ige közé más szó kerül, különírjuk őket. Ha nem kerül közéjük más szó, egybeírjuk.",
      irregularTitle: "Jegyezd meg!",
      irregulars: ["meg akarta beszélni", "meg fogja beszélni", "megbeszéli", "megfogja"],
      image: "magyarazat02.png",
      imageAlt: "Infografika az igekötős igék egybe- és különírásáról"
    }
  },
  {
    id: 4,
    source: "2026. január • központi felvételi • 5. feladat • d)",
    first: "két hetes",
    second: "kéthetes",
    correct: "both",
    tags: ["egybe- és különírás", "jelentés", "időtartam", "számnév"],
    explanation: "Mindkét alak helyes, de mást jelent. A kéthetes időtartamot vagy életkort fejez ki, a két hetes pedig két darab vagy két személy megnevezése lehet.",
    learn: {
      title: "Kéthetes vagy két hetes? Mindkettő helyes, de nem ugyanazt jelenti.",
      comparison: [
        { word: "kéthetes", subtitle: "Egybeírjuk – időtartam vagy életkor", examples: [
          { correct: true, text: "kéthetes szabadság" },
          { correct: true, text: "kéthetes tanfolyam" },
          { correct: true, text: "kéthetes tábor" },
          { correct: true, text: "kéthetes kisbaba" },
          { correct: false, text: "két hetes szabadság" }
        ]},
        { word: "két hetes", subtitle: "Különírjuk – a két a hetes szó darabszámát jelöli", examples: [
          { correct: true, text: "Két hetes vigyáz a rendre." },
          { correct: true, text: "Két hetes kártya van nálam." },
          { correct: true, text: "Két hetest húztam a pakliból." },
          { correct: false, text: "Kéthetes vigyáz a rendre." }
        ]}
      ],
      ruleTitle: "Mi a különbség?",
      rule: "A kéthetes egyetlen melléknév: időtartamot vagy életkort fejez ki. A két hetes szerkezetben a hetes önálló szó, a két pedig azt jelöli, hogy belőle kettő van.",
      formula: "kéthetes = időtartam / életkor ↔ két hetes = két darab / két személy",
      counterTitle: "A jelentés dönt",
      counterText: "A kéthetes szabadság két hétig tart. A Két hetes vigyáz a rendre mondatban viszont két, hetesnek nevezett tanulóról van szó.",
      irregularTitle: "Jegyezd meg!",
      irregulars: ["kéthetes szabadság", "kéthetes kisbaba", "két hetes vigyáz", "két hetes kártya"],
      image: "magyarazat03.png",
      imageAlt: "Infografika a kéthetes és két hetes alak jelentéséről és helyesírásáról"
    }
  },
  {
    id: 5,
    source: "2026. január • központi felvételi • 5. feladat • e)",
    first: "igér",
    second: "ígér",
    correct: "second",
    tags: ["magánhangzó-hosszúság"],
    explanation: "Az ígér szó hosszú í-vel írandó."
  },
  {
    id: 6,
    source: "2026. január • központi felvételi • 5. feladat • f)",
    first: "mohácsi vész",
    second: "Mohácsi Vész",
    correct: "first",
    tags: ["kis- és nagybetű", "történelmi esemény", "ünnep", "nevezetes nap"],
    explanation: "A történelmi események nevét kis kezdőbetűvel írjuk: mohácsi vész. Az ünnepek és nevezetes napok neve is általában kis kezdőbetűs.",
    learn: {
      title: "Ünnepek és történelmi események helyesírása",
      comparison: [
        { word: "Történelmi események", subtitle: "Kis kezdőbetű", examples: [
          { correct: true, text: "a mohácsi vész" },
          { correct: true, text: "a francia forradalom" },
          { correct: true, text: "a honfoglalás" },
          { correct: true, text: "a bécsi kongresszus" },
          { correct: true, text: "a szabadságharc" },
          { correct: false, text: "a Mohácsi Vész" },
          { correct: false, text: "a Francia Forradalom" }
        ]},
        { word: "Ünnepek, nevezetes napok", subtitle: "Kis kezdőbetű", examples: [
          { correct: true, text: "karácsony" },
          { correct: true, text: "húsvét" },
          { correct: true, text: "anyák napja" },
          { correct: true, text: "a magyar kultúra napja" },
          { correct: true, text: "március tizenötödike" },
          { correct: false, text: "Karácsony" },
          { correct: false, text: "Anyák Napja" }
        ]}
      ],
      ruleTitle: "Vigyázz a mondatkezdésre!",
      rule: "A mondat első szavát mindig nagybetűvel kezdjük. Ilyenkor a nagybetű nem a történelmi esemény vagy az ünnep nevéhez tartozik, hanem a mondatkezdés miatt jelenik meg.",
      formula: "Mohácsi vészről tanultunk ma. • Karácsonykor együtt van a család.",
      counterTitle: "A nagybetű csak a mondatkezdés miatt van",
      counterText: "Mondat közben kisbetűs marad: Tanultunk a mohácsi vészről. Szeretem a karácsonyt.",
      irregularTitle: "Jegyezd meg!",
      irregulars: ["történelmi esemény: kisbetű", "ünnep: kisbetű", "nevezetes nap: kisbetű", "mondat elején: nagybetű"],
      image: "magyarazat04.png",
      imageAlt: "Infografika a történelmi események, ünnepek és nevezetes napok kis kezdőbetűs írásáról"
    }
  },
  {
    id: 7,
    source: "2026. január • pótfelvételi • 4. feladat • a)",
    first: "Batthyányi",
    second: "Batthyány",
    correct: "second",
    tags: ["tulajdonnév", "szóalak"],
    explanation: "A családnév helyes alakja: Batthyány."
  },
  {
    id: 8,
    source: "2026. január • pótfelvételi • 4. feladat • b)",
    first: "sajog",
    second: "salyog",
    correct: "first",
    tags: ["j–ly"],
    explanation: "A sajog szóban j-t írunk."
  },
  {
    id: 9,
    source: "2026. január • pótfelvételi • 4. feladat • c)",
    first: "higyj",
    second: "higgy",
    correct: "second",
    tags: ["felszólító mód", "rendhagyó ige", "gy + j"],
    explanation: "A hisz ige felszólító módú alakja nem higyj, hanem higgy. A hagyj viszont helyes: a hagy igéhez a felszólító mód -j jele kapcsolódik.",
    learn: {
      title: "Higgy vagy hagyj? A kiejtés hasonló, az írásmód eltér.",
      comparison: [
        { word: "higgy", subtitle: "A hisz ige rendhagyó felszólító módú alakja", examples: [
          { correct: true, text: "Higgy nekem!" },
          { correct: true, text: "Higgye el!" },
          { correct: true, text: "Higgyük el!" },
          { correct: true, text: "Higgyétek már!" },
          { correct: false, text: "Higyj nekem!" }
        ]},
        { word: "hagyj", subtitle: "A hagy igéhez a felszólító mód -j jele kapcsolódik", examples: [
          { correct: true, text: "Hagyj békén!" },
          { correct: true, text: "Hagyja abba!" },
          { correct: true, text: "Hagyjuk itt!" },
          { correct: true, text: "Hagyjátok nyitva!" },
          { correct: false, text: "Haggy békén!" }
        ]}
      ],
      ruleTitle: "Mi a lényeg?",
      rule: "A hisz ige felszólító módú alakja rendhagyó: higgy. A hagy ige töve gy-re végződik, ehhez kapcsolódik a felszólító mód -j jele, ezért írásban megtartjuk a gy + j kapcsolatot: hagyj.",
      formula: "hisz → higgy • hagy → hagyj",
      counterTitle: "A kiejtés becsaphat",
      counterText: "A hagyj szóban a gy és a j a kiejtésben teljes hasonulással hosszú gy hangként hallatszik, de írásban a gy + j alakot tartjuk meg.",
      irregularTitle: "Rokon példák",
      irregulars: ["higgy", "higgye", "higgyük", "higgyétek", "hagyja", "hagyjuk", "hagyjátok", "fogyjon"],
      image: "magyarazat05.png",
      imageAlt: "Infografika a higgy és hagyj felszólító módú alakok helyesírásáról"
    }
  },
  {
    id: 10,
    source: "2026. január • pótfelvételi • 4. feladat • d)",
    first: "cm-el",
    second: "cm-rel",
    correct: "second",
    tags: ["toldalékolás", "rövidítés"],
    explanation: "A rövidítésekhez a toldalékot kötőjellel kapcsoljuk, és a kiejtés szerinti alakot írjuk: cm-rel.",
    learn: {
      title: "A kiejtés segít",
      body: "A cm rövidítést centiméternek ejtjük, ezért a -val/-vel toldalék hasonult alakja -rel lesz.",
      rule: "Rövidítés + toldalék: kötőjel, a toldalék alakját pedig a kiejtés határozza meg."
    }
  },
  {
    id: 11,
    source: "2026. január • pótfelvételi • 4. feladat • e)",
    first: "fojt",
    second: "folyt",
    correct: "both",
    tags: ["j–ly", "jelentés"],
    explanation: "Mindkettő helyes, de mást jelent: fojt = fullaszt, folyt = folyik vagy folytat.",
    learn: {
      title: "Azonos hangzás, eltérő jelentés",
      body: "A fojt jelentése: fullaszt. A folyt a folyik vagy a folytat igéhez kapcsolódik.",
      rule: "A jelentés alapján dönthető el, melyik alak illik a mondatba."
    }
  },
  {
    id: 12,
    source: "2026. január • pótfelvételi • 4. feladat • f)",
    first: "dél-európai",
    second: "Dél-európai",
    correct: ["first", "both"],
    tags: ["kis- és nagybetű", "földrajzi név", "-i képző", "kötőjel"],
    explanation: "Általában a dél-európai alak helyes. Mondat elején azonban a Dél-európai is elfogadható.",
    learn: {
      title: "Dél-európai vagy dél-európai?",
      comparison: [
        { word: "dél-európai", subtitle: "Ez a helyes alak általában", examples: [
          { correct: true, text: "dél-európai országok" },
          { correct: true, text: "dél-európai táj" },
          { correct: false, text: "Sok Dél-európai ország csatlakozott." }
        ]},
        { word: "Dél-európai", subtitle: "Mondat elején elfogadható", examples: [
          { correct: true, text: "Dél-európai országok is csatlakoztak." },
          { correct: true, text: "Dél-európai tájakról tanultunk." },
          { correct: false, text: "Sok Dél-európai ország csatlakozott." }
        ]}
      ],
      ruleTitle: "A szabály",
      rule: "Az ilyen földrajzi nevek -i képzős alakjában mindkét tagot kisbetűvel kezdjük, és a kötőjelet megtartjuk. Ezért általában a dél-európai alak helyes.",
      formula: "Dél-Kína → dél-kínai • Magas-Tátra → magas-tátrai • Délkelet-Magyarország → délkelet-magyarországi",
      counterTitle: "Fontos!",
      counterText: "A Dél-Európa alak földrajzi név, ezért nagy kezdőbetűs. Ennek melléknévi alakja azonban dél-európai. Mondat elején a nagy kezdőbetű csak a mondatkezdés miatt jelenik meg.",
      irregularTitle: "Jegyezd meg!",
      irregulars: ["-i képzős melléknév: kisbetű + kötőjel", "mondat elején: a nagy kezdőbetű elfogadható", "alapföldrajzi név: nagy kezdőbetű + kötőjel", "pl. holt-tiszai, dél-kínai, magas-tátrai"],
      image: "magyarazat06.png",
      imageAlt: "Infografika a dél-európai alak helyesírásáról"
    }
  }
];